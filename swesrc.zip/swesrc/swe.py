


# Xiao Simulations
#
# L = 40
# g = 32
# dim 400
# nu = 0.5
# U0 = 2.5
# H0 = 4
# TH = 0.48
# TW = 8
# Del x = 0.1, numx = 400
# Del t = 0.0005
#



#--------------------------------------------
# simulations of the 1D swe, this is a basic code
# with viscosity on hu
#
# Tadmor scheme is bsaed on
#
# "Well-balanced and energy stable schemes for the shallow water
# equations with discontinuous topography"
# Ulrik S.Fjordholm, Siddhartha Mishra, Eitan Tadmor
# Journal of Computational Physics
# Volume 230, Issue 14, 2011
# https://doi.org/10.1016/j.jcp.2011.03.042
#
# Gudunov scheme based on
#
# "A simple well-balanced and positive numerical scheme
# for the shallow-water system"
# Emmanuel Audusse, Christophe Chalons, Philippe Ung
# 10.4310/CMS.2015.v13.n5.a11


# Basic stuff - compute the solution
#--------------------------------------------

import numpy as np
import math
from time import perf_counter
#import pickle
import ast
import sys
#import matplotlib.pyplot as plt



class SolnData():
   "Data for the Solution"

   def __init__(self, pdat):

      self.h = np.zeros(pdat.dim, dtype=np.float64)
      self.hu = np.zeros(pdat.dim, dtype=np.float64)
      self.u = np.zeros(pdat.dim, dtype=np.float64)
      self.z = np.zeros(pdat.dim, dtype=np.float64)
      self.dz = np.zeros(pdat.dim, dtype=np.float64)

      self.hout = np.zeros((pdat.dim, int((pdat.Tend - pdat.Tskip)/pdat.dtsubs + 1)), dtype=np.float64)
      self.huout = np.zeros((pdat.dim, int((pdat.Tend - pdat.Tskip)/pdat.dtsubs + 1)), dtype=np.float64)
      self.tout = np.zeros(int((pdat.Tend - pdat.Tskip)/pdat.dtsubs + 1), dtype=np.float64)
      
      #---------------------

      #random phases
      om = 2*np.pi*np.random.uniform(0,1,4)


      
      #Wave Initial Condition     
      for kk in range(pdat.dim):
         xx = pdat.L*kk / (pdat.dim-1)

         # Topography
         if (np.abs(xx - pdat.L*0.5) <= 0.5*pdat.TW): 
            self.z[kk] = pdat.TH*(1-((xx - pdat.L*0.5)/(0.5*pdat.TW))**2)
         #self.z[kk] = pdat.TH*np.abs(np.sin(2.*np.pi/(pdat.L) * xx))
         
         
         perth1 = pdat.ichpert1*pdat.H0 * np.sin(2.*pdat.ichf1*np.pi/pdat.L * xx + om[0])
         perth2 = 0.0
         #perth2 = pdat.ichpert2*pdat.H0 * np.sin(2.*pdat.ichf2*np.pi/pdat.L * xx + om[1])
         self.h[kk] = pdat.H0 + pdat.sh - self.z[kk] + perth1 + perth2

         
         pertu1 = pdat.icupert1*pdat.U0 * np.sin(2.*pdat.icuf1*np.pi/pdat.L * xx + om[2])
         pertu2 = 0.0
         #pertu2 = pdat.icupert2*pdat.U0 * np.sin(2.*pdat.icuf2*np.pi/pdat.L * xx + om[3])
         self.u[kk] = pdat.U0 + pdat.su  + pertu1 + pertu2
         
         self.hu[kk] = self.h[kk] * self.u[kk]


      np.savetxt('z.dat',self.z)

      # index i contains z[i+1]
      self.zp1 = np.roll(self.z,-1)
      # delz[i] = z[i+1] = z[i]
      self.delz   = self.zp1 - self.z
      # delzm1[i] = delz[i-1]
      self.delzm1 = np.roll(self.delz,1)



      self.dz = self.delz
      # dz[i] = z[i] - z[i-1]
#      for jj in range(pdat.dim):
#         self.dz[jj] = self.z[jj] - self.z[jj-1]              
         #--------------
        

      np.savetxt('ich.dat', self.h);
      np.savetxt('icu.dat', self.u);
      np.savetxt('ichu.dat', self.hu);      
      #Wave tt
      tt= 2.0*np.pi/pdat.L
      tt2 = tt*tt
      tt4 = tt2*tt2
      #coefficient for the nonlinear term in the integrator

      self.rhsh     = np.zeros(pdat.dim, dtype=np.float64)
      self.rhshu    = np.zeros(pdat.dim, dtype=np.float64)

      self.k1h   = np.zeros(pdat.dim, dtype=np.float64)
      self.k1hu   = np.zeros(pdat.dim, dtype=np.float64)
      self.k2h   = np.zeros(pdat.dim, dtype=np.float64)
      self.k2hu   = np.zeros(pdat.dim, dtype=np.float64)
      self.k1u = np.zeros(pdat.dim, dtype=np.float64)
            
      self.fftu  = np.zeros(pdat.dim21, dtype=np.complex)
      self.fftu  = np.fft.rfft(self.u) / pdat.dim
   
# -----------------------------------
# End class SolnData
# -----------------------------------


# -----------------------------------
# Class for parameters
# -----------------------------------
class PData:
   def __init__(self):
      self.pdict = dict()

   def update_from_dict(self, d):
      "Update Parameter dict from another Dict"
      self.pdict.update(d)

   
   def update_from_file(self, filename):
      "Update Parameter dict from file"
      dd = dict()
      with open(filename,'r') as tmpfile:
         for line in tmpfile:
            (key, val) = line.split()
            dd[key] = ast.literal_eval(val)            
      self.pdict.update(dd)




   def init_params(self):
      "Init Parameters"

      # init seed
      self.seed  = self.pdict['seed']
      np.random.seed(self.seed)
      print("Seed = ", self.seed)

      self.schemex  = self.pdict['schemex']
      self.schemet  = self.pdict['schemet']
      
      self.dim   = self.pdict['dim']
      self.dim21 = int(self.dim/2 + 1)

      self.g           = self.pdict['g']
      self.g05         = self.g * 0.5
      self.H0          = self.pdict['H0']
      self.U0          = self.pdict['U0']
      self.TH          = self.pdict['TH']
      self.TW          = self.pdict['TW']
      self.L           = self.pdict['L']
      self.nu          = self.pdict['nu']

      # initial conditions
      # levels of perturbation from "flat" solution
      self.icpert1 =  self.pdict['icpert1']
      #self.icpert2 =  self.pdict['icpert2']
      
      om = np.random.uniform(0,self.icpert1,2)
      self.ichpert1 =  om[0]
      self.icupert1 =  om[1]

      #om = np.random.uniform(0,self.icpert2,2)
      #self.ichpert2 =  om[0]
      #self.icupert2 =  om[1]
      
      print("-------------------")
      print("Max IC pert1 level = ",self.icpert1)
      print("Pert1 level h = ",self.ichpert1)
      print("Pert1 level u = ",self.icupert1)


      #print("Max IC pert2 level = ",self.icpert2)
      #print("Pert2 level h = ",self.ichpert2)
      #print("Pert2 level u = ",self.icupert2)
      
      # frequencies of perturbation
      self.icf =  self.pdict['icf']

      self.ichf1 =  np.random.randint(1, self.icf)
      self.ichf2 =  0.0
      self.icuf1 =  np.random.randint(1, self.icf)
      self.icuf2 =  0.0
      print("Pert Frequencies h,u = ",self.ichf1,self.icuf1)
      #print("Pert Frequencies h = ",self.ichf1,self.ichf2)
      #print("Pert Frequencies u = ",self.icuf1,self.icuf2)
      
      # shifts sh and su
      self.su =  self.pdict['su']
      self.sh =  self.pdict['sh']
      print("Shift (sh) for h = ",self.sh)
      print("Shift (su) for u = ",self.su)
      print("Total HO and U0 = ", self.H0 + self.sh, self.U0 + self.su)

      
      self.dx          = self.L / (self.dim - 1)
      self.dx4         = self.dx*(-4)
      self.dxsq        = self.dx**2

      self.dt     = self.pdict['dt']
      self.sqrtdt = math.sqrt(self.dt)
      self.dt05   = 0.5*self.dt
      
      self.Tend = self.pdict['Tend']
      self.Tskip = self.pdict['Tskip']
      # dtsubs = time-step to save solution
      # should be integer multiple of dt
      self.dtsubs = self.pdict['dtsubs']

      self.time = 0.0
      self.timeout = 0.0


      # messaging
      self.dtmes = self.pdict['dtmes']
      #self.mes_into_file = self.pdict['MesFile']
      self.timemes = 0.0

      self.seed = self.pdict['seed']
      np.random.seed(self.seed)
      
      self.nums_subs = int(self.dtsubs/self.dt)
      self.nums      = int((self.Tend - self.Tskip)/self.dtsubs)
      self.nums_skip = int(self.Tskip/self.dt)

   def reset_timeout(self):
      "Reset timout"
      self.timeout = 0.0

   def advance_time(self):
      " Advance All Time Vaiables after 1 time-step"
      self.time    += self.dt
      self.timeout += self.dt
      self.timemes += self.dt
      
      if(self.timemes > self.dtmes):
         self.timemes = 0.0
         with open('mes.txt','w') as tmpfile:
            tmpfile.write(str(self.time))



      
   def output_condition(self):
      "Return Condition to Output Soln into File"
      cond1 = (self.TstartOut - self.dt05) <= self.time <= (self.TstopOut + self.dt05)
      cond2 = self.timeout >= self.dtout - self.dt05
      return (cond1 and cond2)
     
# -----------------------------------
# End class PData
# -----------------------------------

# -----------------------------------
def compute_rhs_tad_old(h,hu):
   "Compute RHS of the Equations; Tadmor scheme"

   solndat.u = hu / h
   u = np.copy(solndat.u)

   hjm1=h[pdat.dim-1]
   hjp1=h[0]
   ujm1=u[pdat.dim-1]
   ujp1=u[0]


   
   for j in range(1, pdat.dim-1):
      hhuu1 = (h[j+1]+h[j])*(u[j+1]+u[j])
      hhuu2 = (h[j]+h[j-1])*(u[j]+u[j-1])
      solndat.rhshu[j] = (hhuu1*(u[j+1]+u[j])*0.5 + pdat.g*(h[j+1]**2+h[j]**2)-\
                   hhuu2*(u[j]+u[j-1])*0.5 - pdat.g*(h[j]**2+h[j-1]**2))/pdat.dx4 - \
                   0.25*pdat.g*((h[j+1] + h[j])*solndat.dz[j] + (h[j] + h[j-1])*solndat.dz[j-1])/pdat.dx + \
                   pdat.nu*(hu[j+1]-2*hu[j]+hu[j-1])/pdat.dxsq
      
      solndat.rhsh[j] = (hhuu1-hhuu2)/pdat.dx4
      
   # for Periodic boundary
   j=0
   hhuu1 = (h[j+1]+h[j])*(u[j+1]+u[j])
   hhuu2 = (h[j]+hjm1)*(u[j]+ujm1)
   solndat.rhshu[j] = (hhuu1*(u[j+1]+u[j])*0.5+pdat.g*(h[j+1]**2+h[j]**2)-\
                   hhuu2*(u[j]+ujm1)*0.5 - pdat.g*(h[j]**2+hjm1**2))/pdat.dx4- \
                   0.25*pdat.g*((h[j+1] + h[j])*solndat.dz[j] + (h[j] + hjm1)*solndat.dz[pdat.dim-1])/pdat.dx + \
                   pdat.nu*(hu[j+1]-2*hu[j]+hu[pdat.dim-1])/pdat.dxsq
   
   # Diffusion Scheme II (Tadmor but epsilon only)
   solndat.rhsh[j] = (hhuu1-hhuu2)/pdat.dx4 
   
   j=pdat.dim-1
   hhuu1 = (hjp1+h[j])*(ujp1+u[j])
   hhuu2 = (h[j]+h[j-1])*(u[j]+u[j-1])
   solndat.rhshu[j] = (hhuu1*(ujp1+u[j])*0.5+pdat.g*(hjp1**2+h[j]**2)-\
                   hhuu2*(u[j]+u[j-1])*0.5 - pdat.g*(h[j]**2+h[j-1]**2))/pdat.dx4- \
                   0.25*pdat.g*((hjp1 + h[j])*solndat.dz[j] + (h[j] + h[j-1])*solndat.dz[j-1])/pdat.dx + \
                   pdat.nu*(hu[0]-2*hu[j]+hu[j-1])/pdat.dxsq
   
   # Diffusion Scheme II (Tadmor but epsilon only)
   solndat.rhsh[j] = (hhuu1-hhuu2)/pdat.dx4


# -----------------------------------
#
# bara  = (a[i+1] + a[i])/2
# dela   = a[i+1] - a[i]
#
def compute_rhs_tad(h,hu):
   "Compute RHS of the Equations; Tadmor scheme"

   solndat.u = hu / h
   u = np.copy(solndat.u)
   

   # now index i contains h[i+1] and u[i+1]
   hup1 = np.roll(hu,-1)
   hp1  = np.roll(h,-1)
   up1  = np.roll(u,-1)

   hbar = (h + hp1) * 0.5
   ubar = (u + up1) * 0.5
   
   fluxh = hbar * ubar
   fluxhm1 = np.roll(fluxh,1)
   solndat.rhsh = -(fluxh - fluxhm1)/pdat.dx

   
   hbarsq = hbar * hbar
   ubarsq = ubar * ubar

   # Viscosity flux for hu
   Fvischu = pdat.nu*(hup1 - hu) / pdat.dx
   
   fluxhu = hbar * ubarsq + pdat.g05*hbarsq - Fvischu
   fluxhum1 = np.roll(fluxhu,1)
   
   topohu = hbar * solndat.delz
   topohum1 = np.roll(topohu,1)

   
   solndat.rhshu = -(fluxhu - fluxhum1)/pdat.dx - pdat.g05*(topohu + topohum1)/pdat.dx
   
# -----------------------------------
def compute_rhs_acu(h,hu):
   "Compute RHS of the Equations; ACU scheme"
   

   solndat.u = hu / h
   u = np.copy(solndat.u)
   

   # now index i contains h[i+1] and u[i+1]
   hup1 = np.roll(hu,-1)
   hp1  = np.roll(h,-1)
   up1  = np.roll(u,-1)


   #print(pdat.time)
   #print(h)

   lamLi   = u - np.sqrt(pdat.g * h)
   lamRi   = u + np.sqrt(pdat.g * h)
   
   # index i now contains Lamli[i+1]
   lamLip1 = np.roll(lamLi,-1)
   lamRip1 = np.roll(lamRi,-1)

   # min(lamL[i], lamL[i+1])
   lamL = np.minimum(lamLi, lamLip1)
   # lamL <= 0
   lamL.clip(max=0)

   # max(lamL[i], lamL[i+1])
   lamR = np.maximum(lamRi, lamRip1)
   # lamR >= 0
   lamR.clip(min=0)

   lamR_lamL = lamR - lamL
   lamRlamL  = lamR * lamL
   tmp = lamR * lamL / lamR_lamL

   # check CFL
   tt1 = np.maximum(-lamL,lamR)
   pdat.cfl = 0.5*pdat.dx / np.amax(tt1)
   if(pdat.dt > pdat.cfl):
      print('CFL Violated')
      print('dt = ',pdat.dt, '   CFL =',pdat.cfl, '  should be dt < cfl')
      
   
   # fL = flux(wL) = flux(w[i]) = flux[i]
   fL1 = hu
   fL2 = hu*u + pdat.g05 * h*h
   # fR = flux(wR) = flux(w[i+1]) = flux[i+1]
   fR1 = np.roll(fL1,-1)
   fR2 = np.roll(fL2,-1)

   indx1 = np.where(lamL >= 0)[0]
   indx2 = np.where((lamL < 0) & (lamR > 0))[0]
   indx3 = np.where(lamR <= 0)[0]

 
 #  for k in range(pdat.dim):
 #     if(lamL[k] >= 0):
 #        print('k=',k,' lamL=',lamL[k])

 #     if(lamR[k] <= 0):
 #        print('k=',k,' lamR=',lamR[k])
      
   
   if(len(indx1) + len(indx2) + len(indx3) != pdat.dim):
      print('Len does not match')
      print(len(indx1), len(indx2), len(indx3))

   if (len(indx1) > 0) or (len(indx3) >0):
      print('Len [lamL=0] = ', len(indx1), '     Len [lamR=0] = ', len(indx3))
 

      
   #----------------------------
   # setup flux FHLL
   #----------------------------
   # index i contains FHLL[i+1/2]
   FHHL1    = np.zeros(pdat.dim, dtype=np.float64)
   FHHL2    = np.zeros(pdat.dim, dtype=np.float64)

   if(len(indx1) > 0):
      FHHL1[indx1] = fL1[indx1]
      FHHL2[indx1] = fL2[indx1]

   if(len(indx3) > 0):
      FHHL1[indx3] = fR1[indx3]
      FHHL2[indx3] = fR2[indx3]

            
   FHHL1[indx2] = (lamR[indx2]*fL1[indx2] - lamL[indx2]*fR1[indx2]) / lamR_lamL[indx2] + \
                  tmp[indx2] * (hp1[indx2] - h[indx2]) 
 
   FHHL2[indx2] = (lamR[indx2]*fL2[indx2] - lamL[indx2]*fR2[indx2]) / lamR_lamL[indx2] + \
                  tmp[indx2] * (hup1[indx2] - hu[indx2])    


   #----------------------------
   # setup flux due to topography
   #----------------------------
   # flux for h due to topography
   Ftopo1 = tmp * solndat.delz

   # {h d_x z} = (h(i) + h(i+1))/2 * delz / delx
   # flux for hu due to topography
   averh = 0.5*(h + hp1)
   FtopoR2 = -lamR * pdat.g * averh * solndat.delz / lamR_lamL
   FtopoL2 = -lamL * pdat.g * averh * solndat.delz / lamR_lamL

   
   # Viscosity flux for hu
   Fvisc2 = pdat.nu*(hup1 - hu) / pdat.dx

   # viscosity
   # + pdat.nu*(hu[j+1]-2*hu[j]+hu[j-1])/pdat.dxsq
   
   #----------------------------
   # setup total flux
   #----------------------------  
   # index i contain FR[i+1/2]
   # no topo - 
   #   FR1 = np.copy(FHHL1)
   #   FR2 = np.copy(FHHL2)
   FR1 = FHHL1 + Ftopo1
   FR2 = FHHL2 + FtopoR2 - Fvisc2
   
   # index i contains FR[i-1/2]   
   FR1m1 = np.roll(FR1,1)
   FR2m1 = np.roll(FR2,1)

   
   # index i contain FL[i+1/2]
   # no topo - 
   #   FL1 = np.copy(FHHL1)
   #   FL2 = np.copy(FHHL2)
   FL1 = FHHL1 + Ftopo1
   FL2 = FHHL2 + FtopoL2 - Fvisc2


   # should be FL(i+1/2) - FR(i-1/2)
   
   solndat.rhsh  = -(FL1 - FR1m1) / pdat.dx
   solndat.rhshu = -(FL2 - FR2m1) / pdat.dx


   # this is without topo
   # in his case FL = FR
   #FHHL1m1 = np.roll(FHHL1,1)
   #FHHL2m1 = np.roll(FHHL2,1)
   
   #solndat.rhsh  = -(FHHL1 - FHHL1m1) / pdat.dx
   #solndat.rhshu = -(FHHL2 - FHHL2m1) / pdat.dx



 
# -----------------------------------
def make_one_step_rk2():
   "Make one Time-Step using RK4 method"
   compute_rhs(solndat.h, solndat.hu)
   
   solndat.k1h = solndat.rhsh * pdat.dt
   solndat.k1hu = solndat.rhshu * pdat.dt


   compute_rhs(solndat.h + 0.5*solndat.k1h, solndat.hu + 0.5*solndat.k1hu)
   solndat.k2h = solndat.rhsh * pdat.dt
   solndat.k2hu = solndat.rhshu * pdat.dt
   
   solndat.h = solndat.h + solndat.k2h
   solndat.hu = solndat.hu + solndat.k2hu 
    

   solndat.u = solndat.hu / solndat.h

   #solndat.fftu = np.fft.rfft(solndat.u)/pdat.dim


# -----------------------------------
def make_one_step_ssprk2():
   "Make one Time-Step using RK2 method"
   compute_rhs(solndat.h,solndat.hu)
   
   solndat.k1h = solndat.h + solndat.rhsh * pdat.dt
   solndat.k1hu = solndat.hu + solndat.rhshu * pdat.dt

   compute_rhs(solndat.k1h, solndat.k1hu)
   solndat.k2h = solndat.k1h + solndat.rhsh * pdat.dt
   solndat.k2hu = solndat.k1hu + solndat.rhshu * pdat.dt
   
   solndat.h = 0.5*(solndat.h + solndat.k2h)
   solndat.hu = 0.5*(solndat.hu + solndat.k2hu)
    

   solndat.u = solndat.hu / solndat.h

   #solndat.fftu = np.fft.rfft(solndat.u)/pdat.dim

   # -----------------------------------

   
def make_one_step_eul():
   "Make one Time-Step using Euler method"

   compute_rhs(solndat.h,solndat.hu)

   solndat.h  = solndat.h + solndat.rhsh * pdat.dt
   solndat.hu = solndat.hu + solndat.rhshu * pdat.dt

   solndat.u = solndat.hu / solndat.h

   #solndat.fftu = np.fft.rfft(solndat.u)/pdat.dim

    
#-------------
def Printhhu(filename1, filename2,pdat):
    
    with open(filename1, 'w') as handle:
       for i in range(pdat.dim):
          for j in range(int((pdat.Tend-pdat.Tskip)/pdat.dtsubs)):
             handle.write(str(solndat.hout[i][j]))
             handle.write(" ")
          handle.write("\n")

    with open(filename2, 'w') as handle:
       for i in range(pdat.dim):
          for j in range(int((pdat.Tend-pdat.Tskip)/pdat.dtsubs)):
             handle.write(str(solndat.huout[i][j]))
             handle.write(" ")
          handle.write("\n")





# -----------------------------------
def compute_rhs(h,hu):
   "Interface; choose the correct RHS"

   if pdat.schemex == 1:
      compute_rhs_tad(h,hu)
   if pdat.schemex == 2:
      compute_rhs_acu(h,hu)
   if pdat.schemex == 3:
      compute_rhs_tad_old(h,hu)

     
# -----------------------------------
def make_one_step():
   "Interface; choose the correct time-stepping"
   
   if pdat.schemet == 1:
      make_one_step_eul()
   if pdat.schemet == 2:
      make_one_step_ssprk2()
   if pdat.schemet == 3:
      make_one_step_rk2()

          
# -----------------------------------
# MAIN PROGRAM
# -----------------------------------
if __name__=='__main__':
   pdat = PData()
   pdat.update_from_file('./swe.in')
   pdat.update_from_file('./init.in')
   
   pdat.init_params()
   g = pdat.g

   # -------------------------
   # General Stuff
   # -------------------------

   # init arrays for solution and integration

   solndat = SolnData(pdat)

   cl1 = perf_counter()
   pdat.clockstart = cl1
   print("-------------------")
   print("Start Computations")
   if pdat.schemex == 1:
      print("Tadmor scheme")
   if pdat.schemex == 2:
      print("Audusse, Chalons, Ung scheme")
   if pdat.schemex == 3:
      print("NEW Tadmor scheme")
      
   if pdat.schemet == 1:
      print("Euler Time-Stepping")
   if pdat.schemet == 2:
      print("SSP RK2 Time-Stepping")
   if pdat.schemet == 3:
      print("RK2 Time-Stepping")

   print("-------------------")


   # Skip up to time Tskip
   for j in range(pdat.nums_skip):
      make_one_step()
      pdat.advance_time()

   print("Time After Skip = ", pdat.time)

   tt = 0
   for ii in range(pdat.dim):
      solndat.hout[ii][0] = solndat.h[ii]
      solndat.huout[ii][0] = solndat.hu[ii]

   solndat.tout[0] = pdat.time

   # ---------------
   # Main Loop
   # After Tskip
   # ---------------
   for j in range(pdat.nums):

     for k in range(pdat.nums_subs):
        make_one_step_eul()
        pdat.advance_time()

     tt = tt + 1   
     for ii in range(pdat.dim):
        solndat.hout[ii][tt] = solndat.h[ii]
        solndat.huout[ii][tt] = solndat.hu[ii]

     solndat.tout[tt] = pdat.time   


   # ---------------
   # End of Main Loop
   # ---------------

   cl2 = perf_counter()
   print("-------------------")
   print("End of Computations, walltime = ", (cl2-cl1), " sec")

   days = int((cl2-cl1)/60/60/24)
   hrs  = int((cl2-cl1)/60/60 - days*24)
   mnts = int((cl2-cl1)/60 - hrs*60.0 - days*60.0*24.0)
   print("    days =", days, "hrs =", hrs, "min =", mnts)
   print("hshape = ",np.shape(solndat.hout))
   print("-------------------")

   #Plot_countour()
   np.savetxt('h.dat',solndat.hout)
   np.savetxt('hu.dat',solndat.huout)
   np.savetxt('t.dat',solndat.tout)

   np.save('h.npy', solndat.hout)
   np.save('hu.npy', solndat.huout)
