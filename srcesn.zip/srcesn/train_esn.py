


import numpy as np
import os
import scipy.sparse as sparse
from time import perf_counter




# global variables
approx_res_size = 5000

data_params = {'dt': 0.1,    #time-step for time-series
                #'nstep': 2000,
                'dim':400,   #dim of h and hu
                'L':40
               }

res_params = {'radius': 0.1,  #specral radius
              'degree': 10,   #num connections per neuron
              'beta1': 0.2,  #range for Win = unif[-beta1,beta1]
              'train_size': 300,  #length of time-series for training
              # N = actual res size
              'N': int(np.floor(approx_res_size / data_params['dim']) * data_params['dim']),
              'num_inputs': 2*data_params['dim'],   #total dim of the data = [h,hu]
              #'predict_size': 600,
              'lam': 5*1e-6,     #regularization param
              'train_num_traj': 20,
              'train_start_traj': 0
              }


# The ESN functions for training
def generate_reservoir(size,radius,degree):
    sparsity = degree/float(size);
    messageout.write('Sparsity of A = '+str(sparsity)+'\n')
    messageout.write('Num connection per neuron = '+str(degree)+'\n')
    A = sparse.rand(size,size,density=sparsity).todense()
    vals = np.linalg.eigvals(A)
    e = np.max(np.abs(vals))
    A = (A/e) * radius
    
    nonz = np.nonzero(A)
    messageout.write('Num non-zero entries A = '+str(nonz[0].size)+'\n')
    return A


def reservoir_layer(A, Win, input, res_params):
    n= np.shape(input)[1]
    states = np.zeros((res_params['N'], n))
    for i in range(n-1):
        if ((i+1) % res_params['train_size'] > 0):  
            states[:,i+1] = np.tanh(np.dot(A,states[:,i]) + np.dot(Win,input[:,i]))
    return states


def train(res_params,states,output):
    lam = res_params['lam']
    idenmat = lam * sparse.identity(res_params['N'])
    states2 = states.copy()
    #nonlinear transformation
    for j in range(np.shape(states2)[0]):
        if (np.mod(j,2)==0):
            states2[j,:] = (states[j,:]**2).copy()
    U = np.dot(states2,states2.transpose()) + idenmat
    Uinv = np.linalg.inv(U)
    Wout = np.dot(Uinv,np.dot(states2, output.transpose()))
    return Wout.transpose()
  
    
def train_reservoir(res_params, data):
    A = generate_reservoir(res_params['N'], res_params['radius'], res_params['degree'])
    messageout.write('Reservoir size ='+str(res_params['N'])+'\n')
    print('--A generated')
    
    # how many non-zero entries of Win per column
    # so, each input affect only q neurons
    q = int(res_params['N']/res_params['num_inputs'])
    messageout.write('Non-zero enries (each col) in Win is q = '+str(q)+'\n')
    
    Win = np.zeros((res_params['N'],res_params['num_inputs']))
    beta1 = res_params['beta1']
    for i in range(res_params['num_inputs']):
        np.random.seed(seed=i)
        Win[i*q: (i+1)*q,i] = beta1 * (-1 + 2 * np.random.rand(1,q)[0])
    print('--Win generated')
    
    states = reservoir_layer(A, Win, data, res_params)
    print('--states generated')
    
    Wout = train(res_params, states, data)
    print('--Wout computed')
    return A, Win, states, Wout 


def topography():
    zz = np.zeros(data_params['dim'])
    for k in range(data_params['dim']):
       xx= data_params['L']*k/(data_params['dim']-1)
       if (xx >= data_params['L']*0.5-4) and (xx <= data_params['L']*0.5+4):
          zz[k] = 0.48*(1-((xx-data_params['L']*0.5)/4)**2)
    return zz



if __name__=='__main__':
        resdir = '../esnres/esn0beta02t30'
        datadir = '../test005/test0'
        
        tst = os.path.isdir(resdir)
        if not tst:
            os.mkdir(resdir)
        
        cl1 = perf_counter()
        
        messageout = open(os.path.join(resdir, 'mesout.txt'), 'w')
        messageout.write('Data dir is  '+datadir+'\n')

        messageout.write(str(data_params)+'\n')
        messageout.write(str(res_params)+'\n')
        messageout.write('-------------------\n')
        # load topography
        #z = topography()
        z = np.loadtxt(datadir+'/r0/z.dat')
        
        
        # how many predictions to use
        # starting directory
        m = res_params['train_num_traj']
        mstart = res_params['train_start_traj']
        train_data = np.zeros((res_params['num_inputs'], res_params['train_size']*m))
        for j in range(m):
            jm = j+mstart
            messageout.write('Using data from  '+datadir+'/r'+str(jm)+'\n')
            h = np.load(datadir+'/r'+str(jm)+'/h.npy')
            hu = np.load(datadir+'/r'+str(jm)+'/hu.npy')         
            for i in range(np.shape(h)[1]):
                h[:,i] = h[:,i] + z
            data = np.concatenate((h, hu), axis=0)
            train_data[:, j*res_params['train_size']: (j+1)*res_params['train_size']] = data[:, : res_params['train_size']]


        print('data prepared')
        messageout.write('-------------------\n')
        
        # Train reservoir
        print('training ESN...')
        A, Win, states, Wout= train_reservoir(res_params, train_data)
        np.save(os.path.join(resdir,'A.npy'), A)
        np.save(os.path.join(resdir,'Win.npy'), Win)
        np.save(os.path.join(resdir,'Wout.npy'), Wout)
        print('training done')
        messageout.write('-------------------\n')
        
        
        cl2 = perf_counter()
        print('-------------------')
        print('End of Computations, walltime = ', (cl2-cl1), ' sec')

        #days = int((cl2-cl1)/60/60/24)
        #hrs  = int((cl2-cl1)/60/60 - days*24)
        #mnts = int((cl2-cl1)/60 - hrs*60.0 - days*60.0*24.0)
        #print('    days =', days, 'hrs =', hrs, 'min =', mnts)
        
        messageout.write('Run time = '+str(cl2-cl1)+' sec')
        
        
        messageout.close()

