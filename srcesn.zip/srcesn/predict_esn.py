


# predict dynamics of the SWE using transfer learning



import numpy as np
import os
import matplotlib.pyplot as plt
import scipy.sparse as sparse
from time import perf_counter


# global variables
approx_res_size = 5000

data_params = {'dt': 0.1,    #time-step for time-series
                #'nstep': 2000,
                'dim':400,   #dim of h and hu
                'L':40
               }

res_params = {'radius': 0.1,  #specral radius
              'degree': 10,   #num connections per neuron
              'beta1': 0.1,  #range for Win = unif[-beta1,beta1]
              'train_size': 200,  #length of time-series for training
              # N = actual res size
              'N': int(np.floor(approx_res_size / data_params['dim']) * data_params['dim']),
              'num_inputs': 2*data_params['dim'],   #total dim of the data = [h,hu]
              'predict_size': 201,     #how many time-steps for prediction
              'warmup_size': 0,     #how many time-steps for reservoir warmup
              'lam' : 5*1e-6,       #regularization param
              'test_num_traj': 20,
              'test_start_traj': 10,
              'use_tranl' : True,   # flag to use transfer learning 
              # alpha increases if the amount of TL data increases
              # range of alpha for 1 tl traj with 100 points = 2*1e-7 ... 5*1e-7
              'alpha' : 5*1e-7,  # tl rate
              'tranl_size' : 50,       # len of the tl trajectory
              'tranl_num_traj' : 1,     # how many trajecories to use for tl
              'tranl_start_traj' : 0    # starting directory for tl
              }



def predict(res_params, A, Win, Wout, out_true):

    # out_true = true trajectory
    # initial condition is out_true[:,0]
    
    predict_size = res_params['predict_size']
    warmup_size = res_params['warmup_size']
    
    # x = initial state of the reservoir
    x = np.zeros(res_params['N'])
    
    # out = solution at time "i" 
    out = out_true[:,0]
    
    # output = the whole predicted trajectory
    output = np.zeros((res_params['num_inputs'], predict_size))
    output[:,0] = out
    
    if warmup_size > 0:
        # warm up = compute states of the reservoir using true solution
        for i in range(warmup_size):
            x1 = np.tanh(np.dot(A, x) + np.dot(Win, out))
            x = np.squeeze(np.asarray(x1))
            out = out_true[:,i+1]
            output[:,i+1] = out         

    # prediction
    for i in range(warmup_size, predict_size-1):
        x1 = np.tanh(np.dot(A, x) + np.dot(Win, out))
        x = np.squeeze(np.asarray(x1))
        x_aug = x.copy()
        #nonlinear transformation; only used for prediction
        for j in range(np.shape(x_aug)[0]):
            if (np.mod(j,2)==0):
                x_aug[j] = (x[j]**2).copy()
                # predicted solution
        out = np.squeeze(np.asarray(np.dot(Wout,x_aug)))
        output[:,i+1] = out 

    return output

      
def compute_error(x, y):
    # L2 error
    l2_err = np.zeros(np.shape(x)[1])
    l2 = 0
    for i in range(np.shape(x)[1]):             
         l2_err[i] = np.sqrt(np.sum(np.power((y[:,i]-x[:,i]), 2)))
         l2 += np.sqrt(np.sum(np.power(y[:,i], 2)))
    l2_err = l2_err / (l2/np.shape(x)[1])
    return  l2_err


def err_plot(figname,  l2_err, ylabel):
    predict_size = np.shape(l2_err)[0]
    pred_time = np.linspace(0, data_params['dt'] *predict_size, predict_size)   
    fig = plt.figure(figsize=(4.5, 3))
    plt.plot(pred_time, l2_err, color='green')
    plt.ylim(bottom=0)
    plt.ylabel(ylabel)
    plt.xlabel('t')
    plt.xlim([0, data_params['dt'] *predict_size])
    plt.tight_layout()
    fig.savefig(os.path.join(resdir,figname))
    plt.show()
    
    
def reservoir_layer(A, Win, input, res_params):
    n= np.shape(input)[1]
    states = np.zeros((res_params['N'], n))
    for i in range(n-1):
        if ((i+1) % res_params['train_size'] > 0):  
            states[:,i+1] = np.tanh(np.dot(A,states[:,i]) + np.dot(Win,input[:,i]))
    return states

    
    
    
    
def transfer_learning(alpha, A, Win, Wout, inputs):
    states = reservoir_layer(A, Win, inputs, res_params)
    idenmat = alpha * sparse.identity(res_params['N'])
    states2 = states.copy()
    #nonlinear transformation
    for j in range(np.shape(states2)[0]):
        if (np.mod(j,2)==0):
            states2[j,:] = (states[j,:]**2).copy()
            
    RR = np.dot(states2,states2.transpose())
    RR_max = np.max(abs(RR))
    print('Max RR = ', RR_max)
    
    RX = np.dot(states2, inputs.transpose())
    RX_max = np.max(abs(RX))
    print('Max RX = ', RX_max)
    
    RRWout = np.dot(RR, Wout.transpose())
    RRWout_max = np.max(abs(RRWout))
    print('Max RRWout = ', RRWout_max)
    
    RRinv = np.linalg.inv(RR)
    RRinv_max = np.max(abs(RRinv))
    print('Max RRinv = ', RRinv_max)
    
    U = RR + idenmat
    Uinv = np.linalg.inv(U) 
    Uinv_max = np.max(abs(Uinv))
    print('Max Uinv = ', Uinv_max)
    
    V = RX - RRWout
    Wnew = np.dot(Uinv, V)
    return Wnew.transpose()


if __name__=='__main__':
        # dir for ESN
        esndir = '../esn005res/esn0beta01'
        # dir for results
        resdir = '../test005res/test8esn0beta01tl5'
        # dir to load testing data
        datadir = '../test005/test8'
        # dir for transfer learning data
        tranl_dir = '../test005/test8'
        
        
        cl1 = perf_counter()
        
        tst = os.path.isdir(resdir)
        if not tst:
            os.mkdir(resdir)
            
        messageout = open(os.path.join(resdir, 'mesout.txt'), 'w')
        messageout.write('ESN dir is  '+esndir+'\n')
        messageout.write('Data dir is  '+datadir+'\n')
        messageout.write('Results dir is  '+resdir+'\n')
        messageout.write('TL dir is  '+tranl_dir+'\n\n')
        messageout.write(str(data_params)+'\n')
        messageout.write(str(res_params)+'\n')
        messageout.write('-------------------\n')
        # load topography
        #z = topography()
        z = np.loadtxt(datadir+'/r0/z.dat')
        fnamez = resdir+'/z.dat'
        np.savetxt(fnamez,z)
        
        # load ESN
        A =np.load(esndir+'/A.npy')
        Win=np.load(esndir+'/Win.npy')
        Wout=np.load(esndir+'/Wout.npy')
        print('ESN is loaded from ',esndir, '  ESN size = ', np.shape(A))
        
        dim = data_params['dim']
        
        # ==== START TL ====
        
        if res_params['use_tranl']:
            print('Using Transfer learning')
            # how many trajectories to use for transfer learning
            m = res_params['tranl_num_traj']
            mstart = res_params['tranl_start_traj']
            tranl_size = res_params['tranl_size']
            train_data = np.zeros((res_params['num_inputs'], tranl_size*m))
            
            for j in range(m):
                jm = j+mstart
                messageout.write('Using data from  '+datadir+'/r'+str(jm)+'\n')
                h = np.load(tranl_dir+'/r'+str(jm)+'/h.npy')
                hu = np.load(tranl_dir+'/r'+str(jm)+'/hu.npy')  
                for i in range(np.shape(h)[1]):
                    h[:,i] = h[:,i] + z
                data = np.concatenate((h, hu), axis=0)
                train_data[:, j*tranl_size: (j+1)*tranl_size] = data[:, : tranl_size]
                
                print('Transfer Learning data ', jm)
                
                
            Wdelta = transfer_learning(res_params['alpha'], A, Win, Wout, train_data)
            print('Transfer learning is done')
            
            Wdelta_max = np.max(abs(Wdelta))
            print('Max Wdelta = ', Wdelta_max)
            messageout.write('Max Wdelta = '+str(Wdelta_max)+'\n')
            Wout_max = np.max(abs(Wout))
            print('Max Old Wout = ', Wout_max)
            print('-------------------')
            messageout.write('Max Old Wout = '+str(Wout_max)+'\n')
            messageout.write('-------------------\n')
            
            Woutnew = Wout + Wdelta
            
            np.save(os.path.join(resdir,'A.npy'), A)
            np.save(os.path.join(resdir,'Win.npy'), Win)
            np.save(os.path.join(resdir,'Woutold.npy'), Wout)
            np.save(os.path.join(resdir,'Wout.npy'), Woutnew)
            np.save(os.path.join(resdir,'Wdelta.npy'), Wdelta)
            
            Wout = Woutnew
            
        # ===== END TL ====
        
        
        # alloc for error
        err_l2_total = np.zeros(res_params['predict_size'])
        err_l2_h = np.zeros(res_params['predict_size'])
        err_l2_hu = np.zeros(res_params['predict_size'])
        
        
        
        # out-sample prediction
        # how many predictions to generate
        # starting directory for testing
        m = res_params['test_num_traj']
        mstart = res_params['test_start_traj']
 
        #load data
        for j in range(mstart,mstart+m):
            messageout.write('Using data from  '+datadir+'/r'+str(j)+'\n')
            h = np.load(datadir+'/r'+str(j)+'/h.npy')
            hu = np.load(datadir+'/r'+str(j)+'/hu.npy')  
            for i in range(np.shape(h)[1]):
                h[:,i] = h[:,i]+z
            data = np.concatenate((h, hu), axis=0)

            print('Testing data ', j)

            out_true = data[:, : res_params['predict_size']]
            # generate prediction
            out_pred = predict(res_params, A, Win, Wout, out_true)
            fname1 = resdir+'/'+'outtrue'+str(j)+'.dat'
            fname2 = resdir+'/'+'outpred'+str(j)+'.dat'
            np.savetxt(fname1,out_true)
            np.savetxt(fname2,out_pred)
            
            #compute error for the j-th trajectory
            l2e = compute_error(out_pred, out_true)
            err_l2_total += l2e
            
            l2e = compute_error(out_pred[0:dim,:], out_true[0:dim,:])
            maxl2e = np.max(l2e)
            print('  max h err = ', maxl2e) 
            messageout.write(' max h err ='+str(maxl2e)+'\n')
            err_l2_h += l2e
            
            l2e = compute_error(out_pred[dim:2*dim,:], out_true[dim:2*dim,:])
            err_l2_hu += l2e
            
            
            
        messageout.write('-------------------\n')
        
        err_l2_total = err_l2_total/m
        err_l2_h = err_l2_h/m
        err_l2_hu = err_l2_hu/m
        
        maxl2eh = np.max(err_l2_h)
        print('  max aver l2 err h = ', maxl2eh) 
        messageout.write(' max aver l2 err h ='+str(maxl2eh)+'\n')
        
        maxl2etot = np.max(err_l2_total)
        print('  max aver l2 err total = ', maxl2etot) 
        messageout.write(' max aver l2 err total ='+str(maxl2etot)+'\n')
        
        fname1 = resdir+'/'+'errl2_tot.dat'
        np.savetxt(fname1,err_l2_total)
        fname1 = resdir+'/'+'errl2_h.dat'
        np.savetxt(fname1,err_l2_h)
        fname1 = resdir+'/'+'errl2_hu.dat'
        np.savetxt(fname1,err_l2_hu)
        
        #err_plot('err_l2_tot', err_l2_total,'<L2 Err total>')
        err_plot('err_l2_h', err_l2_h,'<L2 Err h>')
        err_plot('err_l2_hu', err_l2_hu,'<L2 Err hu>')
        
        
        cl2 = perf_counter()
        print('-------------------')
        print('End of Computations, walltime = ', (cl2-cl1), ' sec')

        #days = int((cl2-cl1)/60/60/24)
        #hrs  = int((cl2-cl1)/60/60 - days*24)
        #mnts = int((cl2-cl1)/60 - hrs*60.0 - days*60.0*24.0)
        #print('    days =', days, 'hrs =', hrs, 'min =', mnts)
        
        messageout.write('Run time = '+str(cl2-cl1)+' sec')
        
        
        
        messageout.close()

